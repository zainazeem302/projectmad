package com.example.pizza

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
